as.dsm <- function (obj, ...)  UseMethod("as.dsm")
